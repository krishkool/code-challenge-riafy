'''
Given a matrix M[ ][ ] of dimensions N * N, consisting only of integers from the
range 1 to N, the task is to compute the sum of the matrix elements present in the
main diagonal, the number of rows and columns containing repeated values.
Input: N = 4, M[][] = {{1, 2, 3, 4}, {2, 1, 4, 3}, {3, 4, 1,
2}, {4, 3, 2, 1}}
Output: 4 0 0*

 '''

n = 3
matrix = []
for i in range(0,n):
    a = []
    for j in range(0,n):
        a.append(int(input("Enter value : ")))
    matrix.append(a)


print(matrix)