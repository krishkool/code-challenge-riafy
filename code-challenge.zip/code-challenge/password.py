''' Write a function that evaluates an input string and validates the presence of the
following.
● At least 8 characters
● At least one uppercase letter
● At least one number
● At least one special character
● Does not contain the substrings 123, qwerty, abc'''



def passwordValidate():
    pass_inp = input("Enter a Password : ")
    symbols = ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')']
    if (len(pass_inp) < 8):
        print("The length of password should be 8 or more...")
        exit()

    if not any(char.isupper() for char in pass_inp): 
        print("Password should contain one uppercase...")

    elif not any(char.isdigit() for char in pass_inp): 
        print("Password should contain one number...")

    elif not any(char.isupper() for char in pass_inp): 
        print("Password should contain one uppercase...")

    elif not any(char in symbols for char in pass_inp): 
        print("Password should contain one special characters...") 
    else:
        print("Password successfully validated...")
        

passwordValidate()



